print(type("문자타입데이터"))  #str
print(type(123))              #int
print(type(True))             #boolean
print(type(3.141592)) type()  #float