# 산술연산자 : +, -, *, /, %
x=10
y=20
print("x+y = ", x+y, end='\n' )
print("x-y = ", x-y, end='\n' )
print("x*y = ", x*y, end='\n' )
print("x/y = ", x/y, end='\n' )
print("x%y = ", x%y, end='\n' )
print("2 ** 2", 2**2)

# print("서로다른 타입의 자료형 연산" + 2) #TypeError: can only concatenate str (not "int") to str

#대입연산자 :  =, 다른연산자= ( +=, *=,....)
sum = 100
sum += x #sum=sum+x
print("대입연산자 :sum= ",sum)


# 논리연산자(and, or, not)
# 비교연산자(관계연산자 >, <, >=, <=, ==, !=)

print()
#삼항연산자